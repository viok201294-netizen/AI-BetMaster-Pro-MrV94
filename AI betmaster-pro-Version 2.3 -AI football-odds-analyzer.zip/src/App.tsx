import * as React from 'react';
import { useState, useMemo, useEffect, useRef, Component } from 'react';
import { 
  CreditCard, 
  Bell, 
  Search, 
  Home, 
  Heart, 
  List, 
  ShoppingCart, 
  MoreHorizontal,
  ArrowUpRight,
  ChevronRight,
  TrendingUp,
  Calculator,
  Star,
  RefreshCcw,
  CheckCircle2,
  AlertCircle,
  Trophy,
  User,
  Camera,
  Globe,
  X,
  Save
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';

// --- Types ---

interface OddsInput {
  homeTeam: string;
  awayTeam: string;
  mainLine: string;
  bttsO15: string;
  bttsO25: string;
  mainHandicap: string;
}

interface AnalysisStep {
  title: string;
  value: string | number;
  evaluation: string;
  color: string;
  details?: string;
}

// --- Constants & Helpers ---

const COLORS = {
  red: 'text-red-500 border-red-500 bg-red-50',
  orange: 'text-orange-500 border-orange-500 bg-orange-50',
  yellow: 'text-yellow-500 border-yellow-500 bg-yellow-50',
  blue: 'text-blue-500 border-blue-500 bg-blue-50',
  black: 'text-gray-900 border-gray-900 bg-gray-100',
};

const hexToRgb = (hex: string) => {
  if (!hex || typeof hex !== 'string' || hex.length < 7) return '249, 115, 22';
  try {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    if (isNaN(r) || isNaN(g) || isNaN(b)) return '249, 115, 22';
    return `${r}, ${g}, ${b}`;
  } catch (e) {
    return '249, 115, 22';
  }
};

const getImpliedProb = (odds: number) => (1 / odds) * 100;

// --- Components ---

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends React.Component<any, any> {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center space-y-6 bg-white dark:bg-black">
          <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-black dark:text-white uppercase tracking-tight">Oops! Something went wrong</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 max-w-xs mx-auto">
              The application encountered an unexpected error. Don't worry, your data is safe.
            </p>
          </div>
          <button 
            onClick={() => {
              localStorage.removeItem('userProfile'); // Clear potentially corrupted profile
              window.location.reload();
            }}
            className="px-8 py-4 bg-orange-500 text-white rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-orange-500/20 hover:scale-105 transition-transform"
          >
            Reset & Refresh
          </button>
        </div>
      );
    }

    return (this as any).props.children; 
  }
}

interface SavedMatch {
  id: string;
  homeTeam: string;
  awayTeam: string;
  recommendation: string;
  bet: string;
  confidence: number;
  timestamp: number;
  result?: 'win' | 'loss' | 'pending';
  // Store original odds to reconstruct full analysis
  mainLine: string;
  bttsO15: string;
  bttsO25: string;
  mainHandicap: string;
}

interface UserProfile {
  name: string;
  avatar: string;
  bio: string;
  id: string;
  language: 'en' | 'vi';
  theme: 'light' | 'dark' | 'realtime' | 'custom';
  customColor: string;
}

// --- Translations ---

const translations = {
  en: {
    memberId: "Member ID",
    fullName: "Full Name",
    shortBio: "Short Bio",
    language: "Language",
    saveChanges: "Save Changes",
    analyzing: "Analyzing Match",
    designBy: "Design By Mr.V94",
    homeTeam: "Home Team",
    awayTeam: "Away Team",
    mainLine: "Main Over/Under",
    analyzeMatch: "Analyze Match",
    recommendedBet: "Recommended Bet",
    analysisResults: "Analysis Results",
    backToInputs: "Back to Inputs",
    optimalEntry: "Optimal Entry",
    savedMatches: "Saved Matches",
    items: "ITEMS",
    noSavedMatches: "No analysis data",
    savedMatchesDesc: "Currently the system has no analysis data, please import data.",
    highWinProb: "High Win Probability",
    matchAnalysisBoard: "Match Analysis Board",
    realTimePredictions: "Real-time High-Accuracy Predictions",
    analysisConfirmed: "Analysis Confirmed",
    enterOver: "Enter Over",
    enterUnder: "Enter Under",
    protectHalf: "to protect half stake.",
    inputMissing: "You haven't entered data! Please fill in all information.",
    teamA: "Team A",
    teamB: "Team B",
    odds: "Odds",
    betHistory: "Bet History",
    year: "Year",
    month: "Month",
    day: "Day",
    more: "More",
    updateData: "Import Data",
    uploadFile: "Import from Storage",
    resetData: "Reset All Analysis",
    resetConfirm: "Are you sure you want to reset all data?",
    theme: "Theme",
    themeLight: "Light",
    themeDark: "Dark",
    themeRealTime: "Real-time",
    themeCustom: "Custom",
    selectFile: "Select file (txt, py, code, prompt, notepad)",
    dataUpdated: "Data updated successfully!",
    codeManagement: "Code Management",
    editSystem: "Edit Analysis System",
    viewAccuracy: "View Accuracy",
    win: "Win",
    loss: "Loss",
    pending: "Pending",
    pythonSupport: "Python Support Enabled",
    saveCode: "Save Code",
    systemUpdated: "System updated successfully!",
    mainHandicap: "Main Handicap",
    matchesTitle: "Matches",
    notification: "Notification",
    vipSuggestion: "VIP SUGGESTION",
    savedMatch: "SAVED MATCH",
    pickAccentColor: "Pick Accent Color",
    step1Title: "Overall P(≥3)",
    step2Title: "Suggested Handicap",
    step3Title: "Difference",
    step3Desc: "Compared to main line",
    evalLarge: "LARGE - Trap Alert",
    evalMedium: "MEDIUM - Cautious",
    evalSmall: "SMALL - Similar",
    ver5System: "Ver 5.0 System. Handicap Diff:",
    over: "Over",
    under: "Under"
  },
  vi: {
    memberId: "Mã Thành Viên",
    fullName: "Họ và Tên",
    shortBio: "Tiểu sử ngắn",
    language: "Ngôn ngữ",
    saveChanges: "Lưu thay đổi",
    analyzing: "Đang phân tích trận đấu",
    designBy: "Thiết kế bởi Mr.V94",
    homeTeam: "Đội Nhà",
    awayTeam: "Đội Khách",
    mainLine: "Tỷ lệ O/U chính",
    analyzeMatch: "Phân tích trận đấu",
    recommendedBet: "Kèo đề xuất",
    analysisResults: "Kết quả phân tích",
    backToInputs: "Quay lại nhập liệu",
    optimalEntry: "Điểm vào lệnh tối ưu",
    savedMatches: "Trận đấu ưa thích",
    items: "MỤC",
    noSavedMatches: "Không có dữ liệu phân tích",
    savedMatchesDesc: "Hiện tại hệ thống không có phân tích dữ liệu, vui lòng nhập dữ liệu",
    highWinProb: "Tỷ lệ thắng cao",
    matchAnalysisBoard: "Bảng phân tích trận đấu",
    realTimePredictions: "Dự đoán chính xác cao theo thời gian thực",
    analysisConfirmed: "Đã xác nhận phân tích",
    enterOver: "Vào lệnh Tài",
    enterUnder: "Vào lệnh Xỉu",
    protectHalf: "để bảo vệ nửa tiền cược.",
    inputMissing: "Bạn chưa nhập dữ liệu! Vui lòng điền đầy đủ thông tin.",
    teamA: "Đội A",
    teamB: "Đội B",
    odds: "Tỷ lệ",
    betHistory: "Lịch sử cược",
    year: "Năm",
    month: "Tháng",
    day: "Ngày",
    more: "Cài Đặt",
    updateData: "Nhập dữ liệu",
    uploadFile: "Nhập dữ liệu từ bộ nhớ",
    resetData: "Đặt lại tất cả phân tích",
    resetConfirm: "Bạn có chắc chắn muốn đặt lại tất cả dữ liệu?",
    theme: "Giao diện",
    themeLight: "Sáng",
    themeDark: "Tối",
    themeRealTime: "Theo giờ thực",
    themeCustom: "Tùy chỉnh",
    selectFile: "Chọn tệp (txt, py, code, prompt, notepad)",
    dataUpdated: "Dữ liệu đã được cập nhật!",
    codeManagement: "Quản lý đoạn mã",
    editSystem: "Chỉnh sửa hệ thống phân tích",
    viewAccuracy: "Xem độ chính xác",
    win: "Thắng",
    loss: "Thua",
    pending: "Chờ kết quả",
    pythonSupport: "Đã hỗ trợ Python",
    saveCode: "Lưu đoạn mã",
    systemUpdated: "Hệ thống đã được cập nhật!",
    mainHandicap: "Kèo Chấp Chính",
    matchesTitle: "Trận Đấu",
    notification: "Thông báo",
    vipSuggestion: "GỢI Ý VIP",
    savedMatch: "TRẬN ĐÃ LƯU",
    pickAccentColor: "Chọn màu nhấn",
    step1Title: "P(≥3) Tổng thể",
    step2Title: "Mức chấp gợi ý",
    step3Title: "Chênh lệch",
    step3Desc: "So với kèo chính",
    evalLarge: "LỚN - Cảnh giác bẫy",
    evalMedium: "VỪA - Thận trọng",
    evalSmall: "NHỎ - Tương đồng",
    ver5System: "Hệ thống Ver 5.0. Chênh lệch chấp:",
    over: "Tài",
    under: "Xỉu"
  }
};

// --- Components ---

const VNTime = () => {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const vnTime = new Intl.DateTimeFormat('vi-VN', {
        timeZone: 'Asia/Ho_Chi_Minh',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).format(now);
      setTime(vnTime);
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center gap-2 bg-black/20 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10">
      <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
      <span className="text-[10px] font-black font-mono tracking-widest text-white">VN: {time}</span>
    </div>
  );
};

const ProfileModal = ({ isOpen, onClose, profile, onSave }: { 
  isOpen: boolean; 
  onClose: () => void; 
  profile: UserProfile;
  onSave: (p: UserProfile) => void;
}) => {
  const [tempProfile, setTempProfile] = useState(profile);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[tempProfile.language];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempProfile(prev => ({ ...prev, avatar: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center px-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        className="relative w-full max-w-sm bg-white dark:bg-gray-900 rounded-[40px] overflow-hidden shadow-2xl"
      >
        {/* Credit Card Style Header */}
        <div className="h-48 bg-gradient-to-br from-gray-900 to-black p-8 text-white relative flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="w-12 h-8 bg-yellow-500/20 rounded-md border border-yellow-500/30 flex items-center justify-center">
              <div className="w-8 h-6 bg-yellow-500/40 rounded-sm" />
            </div>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-[0.3em] opacity-50">{t.memberId}</p>
            <p className="text-lg font-mono tracking-widest">{profile.id}</p>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute top-1/2 right-8 -translate-y-1/2 flex -space-x-4 opacity-20">
            <div className="w-16 h-16 rounded-full bg-white" />
            <div className="w-16 h-16 rounded-full bg-white" />
          </div>
        </div>

        <div className="p-8 -mt-12 relative z-10">
          <div className="flex flex-col items-center gap-6">
            <div className="relative group">
              <div className="w-24 h-24 rounded-full border-4 border-white shadow-xl overflow-hidden bg-gray-100">
                {tempProfile.avatar ? (
                  <img src={tempProfile.avatar} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                    <User className="w-10 h-10" />
                  </div>
                )}
              </div>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
              >
                <Camera className="w-4 h-4" />
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                className="hidden" 
                accept="image/*"
              />
            </div>

            <div className="w-full space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t.fullName}</label>
                <input 
                  type="text" 
                  value={tempProfile.name}
                  onChange={(e) => setTempProfile(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full bg-gray-50 dark:bg-white/5 border-none rounded-2xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-orange-500 transition-all dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t.shortBio}</label>
                <textarea 
                  value={tempProfile.bio}
                  onChange={(e) => setTempProfile(prev => ({ ...prev, bio: e.target.value }))}
                  className="w-full bg-gray-50 dark:bg-white/5 border-none rounded-2xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-orange-500 transition-all h-20 resize-none dark:text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{t.language}</label>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setTempProfile(prev => ({ ...prev, language: 'vi' }))}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${tempProfile.language === 'vi' ? 'bg-orange-500 text-white border-orange-500' : 'bg-gray-50 text-gray-400 border-gray-100'}`}
                  >
                    Tiếng Việt
                  </button>
                  <button 
                    onClick={() => setTempProfile(prev => ({ ...prev, language: 'en' }))}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${tempProfile.language === 'en' ? 'bg-orange-500 text-white border-orange-500' : 'bg-gray-50 text-gray-400 border-gray-100'}`}
                  >
                    English
                  </button>
                </div>
              </div>
            </div>

            <button 
              onClick={() => onSave(tempProfile)}
              className="w-full bg-black text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors"
            >
              <Save className="w-5 h-5" /> {t.saveChanges}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const TopNav = ({ onOpenProfile, userAvatar }: { onOpenProfile: () => void; userAvatar: string }) => {
  const playSound = () => {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3');
    audio.volume = 0.5;
    audio.play().catch(() => {}); // Ignore errors if browser blocks autoplay
  };

  const handleLogoClick = () => {
    playSound();
    // Small delay to let the animation and sound play before reload
    setTimeout(() => {
      window.location.reload();
    }, 300);
  };

  return (
    <nav className="flex items-center justify-between px-6 py-4 bg-white/80 dark:bg-black/80 backdrop-blur-md sticky top-0 z-40 border-b border-gray-100 dark:border-white/5">
      <button 
        onClick={onOpenProfile}
        className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 dark:bg-white/10 hover:bg-gray-200 dark:hover:bg-white/20 transition-colors relative overflow-hidden"
      >
        {userAvatar ? (
          <img src={userAvatar} alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        ) : (
          <CreditCard className="w-5 h-5 text-gray-700" />
        )}
      </button>
      <div className="flex items-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.9 }}
          onClick={handleLogoClick}
          className="relative w-20 h-20 flex items-center justify-center group"
        >
          {/* Orbiting Text */}
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 pointer-events-none"
          >
            <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
              <defs>
                <path id="circlePath" d="M 50, 50 m -35, 0 a 35,35 0 1,1 70,0 a 35,35 0 1,1 -70,0" />
              </defs>
              <text className="text-[10px] font-black fill-orange-500 uppercase tracking-[0.2em]">
                <textPath href="#circlePath" startOffset="0%">
                  WC 2026 • WC 2026 • WC 2026 •
                </textPath>
              </text>
            </svg>
          </motion.div>

          {/* 3D Ball Container */}
          <div className="relative w-14 h-14 flex items-center justify-center rounded-full bg-gradient-to-b from-gray-100 to-white shadow-inner overflow-hidden border border-gray-200">
            <motion.div
              animate={{ 
                rotate: 360,
                y: [0, -2, 0]
              }}
              transition={{ 
                rotate: { duration: 15, repeat: Infinity, ease: "linear" },
                y: { duration: 5, repeat: Infinity, ease: "easeInOut" }
              }}
              className="w-10 h-10 relative z-10"
            >
              <img 
                src="https://cdn-icons-png.flaticon.com/512/33/33736.png" 
                alt="World Cup Football" 
                className="w-full h-full object-contain filter drop-shadow-[0_4px_6px_rgba(0,0,0,0.2)]"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            
            {/* Subtle Glossy Overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-white/40 to-transparent pointer-events-none z-20" />
          </div>
        </motion.button>
      </div>
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 dark:bg-white/10">
            <Bell className="w-5 h-5 text-gray-700 dark:text-gray-300" />
          </div>
          <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-black" />
        </div>
        <div className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 dark:bg-white/10">
          <Search className="w-5 h-5 text-gray-700 dark:text-gray-300" />
        </div>
      </div>
    </nav>
  );
};

const BottomNav = ({ activeTab, onTabChange }: { activeTab: string; onTabChange: (tab: string) => void }) => (
  <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50">
    <div className="bg-black/90 backdrop-blur-xl px-8 py-4 rounded-[40px] flex items-center gap-8 shadow-2xl">
      <button onClick={() => onTabChange('home')}>
        <Home className={`w-6 h-6 ${activeTab === 'home' ? 'text-white' : 'text-gray-500'}`} />
      </button>
      <button onClick={() => onTabChange('saved')}>
        <Heart className={`w-6 h-6 ${activeTab === 'saved' ? 'text-white' : 'text-gray-500'}`} />
      </button>
      <button onClick={() => onTabChange('more')}>
        <MoreHorizontal className={`w-6 h-6 ${activeTab === 'more' ? 'text-white' : 'text-gray-500'}`} />
      </button>
    </div>
  </div>
);

const InputField = ({ label, value, onChange, placeholder, type = "text" }: any) => (
  <div className="flex flex-col gap-2">
    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">
      {label}
    </label>
    <input
      type={type}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full bg-gray-50 dark:bg-white/5 border-none rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-orange-500 transition-all font-medium dark:text-white"
    />
  </div>
);

const GoalLoading = ({ onComplete, language }: { onComplete: () => void; language: 'en' | 'vi' }) => {
  const t = translations[language];
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white">
      <div className="w-full max-w-xs px-6 space-y-12">
        <div className="relative">
          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 2.5, ease: "linear" }}
              className="h-full bg-orange-500"
            />
          </div>
          <motion.div
            initial={{ left: "0%" }}
            animate={{ left: "calc(100% - 32px)" }}
            transition={{ duration: 2.5, ease: "linear" }}
            className="absolute top-1/2 -translate-y-1/2 z-20"
          >
            <motion.div
              animate={{ rotate: 360 * 4 }}
              transition={{ duration: 2.5, ease: "linear" }}
              className="text-3xl"
            >
              ⚽
            </motion.div>
          </motion.div>
        </div>
        <div className="text-center space-y-2">
          <p className="text-[10px] font-black uppercase tracking-[0.4em] text-orange-600">{t.analyzing}</p>
          <p className="text-xs text-gray-400">{t.designBy}</p>
        </div>
      </div>
    </div>
  );
};

const Toast = ({ message, onHide, language }: { message: string; onHide: () => void; language: 'en' | 'vi' }) => {
  const t = translations[language];
  useEffect(() => {
    const timer = setTimeout(onHide, 3000);
    return () => clearTimeout(timer);
  }, [onHide]);

  return (
    <>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onHide}
        className="fixed inset-0 z-[95] bg-black/40 backdrop-blur-sm"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.8, x: '-50%', y: '-50%' }}
        animate={{ opacity: 1, scale: 1, x: '-50%', y: '-50%' }}
        exit={{ opacity: 0, scale: 0.8, x: '-50%', y: '-50%' }}
        className="fixed top-1/2 left-1/2 z-[100] bg-white dark:bg-gray-900 text-gray-900 dark:text-white px-8 py-10 rounded-[40px] shadow-2xl flex flex-col items-center gap-6 min-w-[320px] max-w-[90%] text-center border border-gray-100 dark:border-white/10"
      >
        <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center">
          <AlertCircle className="w-10 h-10 text-red-500" />
        </div>
        <div className="space-y-2">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-red-500">{t.notification}</p>
          <p className="text-sm font-bold leading-relaxed">{message}</p>
        </div>
        <button 
          onClick={onHide}
          className="w-full bg-black dark:bg-white dark:text-black text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:scale-105 transition-transform"
        >
          Đã hiểu
        </button>
      </motion.div>
    </>
  );
};

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [heroColorIndex, setHeroColorIndex] = useState(0);
  const [heroSlideIndex, setHeroSlideIndex] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [isDataImported, setIsDataImported] = useState(() => localStorage.getItem('isDataImported') === 'true');
  const [analysisCode, setAnalysisCode] = useState(() => localStorage.getItem('analysisCode') || '');
  const [isEditingCode, setIsEditingCode] = useState(false);
  const [tempCode, setTempCode] = useState(analysisCode);

  const vipSuggestions = useMemo(() => [
    { id: 1, home: "Real Madrid", away: "Man City", type: "OVER", confidence: 5 },
    { id: 2, home: "Liverpool", away: "Arsenal", type: "UNDER", confidence: 4 },
    { id: 3, home: "Bayern", away: "PSG", type: "OVER", confidence: 5 },
  ], []);

  const [inputs, setInputs] = useState<OddsInput>({
    homeTeam: '',
    awayTeam: '',
    mainLine: '2.5',
    bttsO15: '',
    bttsO25: '',
    mainHandicap: '0',
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResult, setShowResult] = useState(false);
  
  const [savedMatches, setSavedMatches] = useState<SavedMatch[]>(() => {
    const saved = localStorage.getItem('savedMatches');
    return saved ? JSON.parse(saved) : [];
  });

  const [recentAnalyses, setRecentAnalyses] = useState<SavedMatch[]>(() => {
    const saved = localStorage.getItem('recentAnalyses');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('recentAnalyses', JSON.stringify(recentAnalyses));
  }, [recentAnalyses]);

  useEffect(() => {
    localStorage.setItem('savedMatches', JSON.stringify(savedMatches));
  }, [savedMatches]);

  const [profile, setProfile] = useState<UserProfile>(() => {
    const defaultProfile: UserProfile = {
      name: 'Mr. V94',
      avatar: 'https://raw.githubusercontent.com/viok201294/images/main/logo_v94.jpg',
      bio: 'Football Analyst & UI Designer',
      id: 'V94-8888-2026',
      language: 'vi',
      theme: 'light',
      customColor: '#f97316'
    };
    const saved = localStorage.getItem('userProfile');
    if (!saved) return defaultProfile;
    try {
      const parsed = JSON.parse(saved);
      return { ...defaultProfile, ...parsed };
    } catch (e) {
      return defaultProfile;
    }
  });

  const heroGradients = useMemo(() => {
    if (profile.theme === 'custom') {
      return [
        `from-[var(--accent-color)] to-orange-400`,
        `from-[var(--accent-color)] to-blue-400`,
        `from-[var(--accent-color)] to-emerald-400`,
        `from-[var(--accent-color)] to-purple-400`,
        `from-[var(--accent-color)] to-rose-400`
      ];
    }
    return [
      'from-orange-500 to-yellow-400',
      'from-indigo-600 to-purple-500',
      'from-emerald-500 to-teal-400',
      'from-rose-500 to-pink-500',
      'from-blue-600 to-cyan-500'
    ];
  }, [profile.theme, profile.customColor]);

  useEffect(() => {
    const interval = setInterval(() => {
      setHeroColorIndex((prev) => (prev + 1) % heroGradients.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [heroGradients.length]);

  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    const updateTheme = () => {
      if (profile.theme === 'realtime') {
        const hour = new Date().getHours();
        setCurrentTheme(hour >= 6 && hour < 18 ? 'light' : 'dark');
      } else {
        setCurrentTheme(profile.theme === 'dark' ? 'dark' : 'light');
      }
    };
    updateTheme();
    const timer = setInterval(updateTheme, 60000);
    return () => clearInterval(timer);
  }, [profile.theme]);

  useEffect(() => {
    if (currentTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [currentTheme]);

  useEffect(() => {
    localStorage.setItem('userProfile', JSON.stringify(profile));
  }, [profile]);

  const t = translations[profile.language];
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const analysis = useMemo(() => {
    const b15 = parseFloat(inputs.bttsO15);
    const b25 = parseFloat(inputs.bttsO25);
    const mainLineNum = parseFloat(inputs.mainLine) || 2.5;
    const mainHandicapNum = parseFloat(inputs.mainHandicap) || 0;

    if (isNaN(b15) || isNaN(b25)) return null;

    // Ver 5.0 Logic
    const p_ge3_tong = (1 / b25) + 0.05;
    let recommendation = "";
    let muc_an_toan = 0;
    
    if (p_ge3_tong > 0.51) {
      recommendation = "OVER";
      muc_an_toan = mainLineNum - 0.25;
    } else {
      recommendation = "UNDER";
      muc_an_toan = mainLineNum + 0.25;
    }
    
    muc_an_toan = Math.round(muc_an_toan * 4) / 4;

    // Handicap calculation
    let base = ((1.83 - b15) / 0.28) * 0.5;
    const gap = b25 - b15;
    if (gap <= 0.20) base += 0.25;
    else if (gap >= 0.30) base -= 0.25;
    
    if (mainLineNum >= 2.75) base += 0.25;
    else if (mainLineNum <= 2.25) base -= 0.25;
    
    const goiy_chap = Math.round(base * 4) / 4;
    const diff = goiy_chap - mainHandicapNum;
    
    let evaluation = "";
    if (Math.abs(diff) >= 0.5) evaluation = t.evalLarge;
    else if (Math.abs(diff) >= 0.25) evaluation = t.evalMedium;
    else evaluation = t.evalSmall;

    const step1 = { title: t.step1Title, value: `${(p_ge3_tong * 100).toFixed(1)}%`, evaluation: recommendation, color: recommendation === "OVER" ? COLORS.red : COLORS.black };
    const step2 = { title: t.step2Title, value: goiy_chap, evaluation: evaluation, color: Math.abs(diff) >= 0.5 ? COLORS.orange : COLORS.blue };
    const step3 = { title: t.step3Title, value: diff.toFixed(2), evaluation: t.step3Desc, color: COLORS.black };

    return { 
      step1, 
      step2, 
      step3, 
      step5: { 
        recommendation, 
        bet: `${recommendation === "OVER" ? t.over : t.under} ${muc_an_toan}`, 
        confidence: p_ge3_tong > 0.6 ? 5 : 4, 
        reason: `${t.ver5System} ${diff.toFixed(2)}` 
      } 
    };
  }, [inputs]);

  const displaySuggestions = useMemo(() => {
    // Combine saved matches and recent analyses, remove duplicates by ID
    const combined = [...recentAnalyses, ...savedMatches]
      .sort((a, b) => b.timestamp - a.timestamp);
    
    const unique = Array.from(new Map(combined.map(m => [m.id, m])).values())
      .slice(0, 3)
      .map(m => ({
        id: m.id,
        home: m.homeTeam,
        away: m.awayTeam,
        type: m.recommendation,
        confidence: m.confidence,
        isRecent: true
      }));
    
    if (unique.length >= 3) return unique;
    
    // Fill with VIP suggestions if not enough matches
    return [...unique, ...vipSuggestions.slice(0, 3 - unique.length)];
  }, [savedMatches, recentAnalyses, vipSuggestions]);

  const toggleSaveMatch = () => {
    if (!analysis) return;
    
    const matchId = `${inputs.homeTeam}-${inputs.awayTeam}`;
    const isAlreadySaved = savedMatches.some(m => m.id === matchId);
    
    if (isAlreadySaved) {
      setSavedMatches(prev => prev.filter(m => m.id !== matchId));
    } else {
      const newMatch: SavedMatch = {
        id: matchId,
        homeTeam: inputs.homeTeam,
        awayTeam: inputs.awayTeam,
        recommendation: analysis.step5.recommendation,
        bet: analysis.step5.bet,
        confidence: analysis.step5.confidence,
        timestamp: Date.now(),
        mainLine: inputs.mainLine,
        bttsO15: inputs.bttsO15,
        bttsO25: inputs.bttsO25,
        mainHandicap: inputs.mainHandicap
      };
      setSavedMatches(prev => [newMatch, ...prev]);
    }
  };

  const loadSavedMatch = (match: SavedMatch) => {
    setInputs({
      homeTeam: match.homeTeam,
      awayTeam: match.awayTeam,
      mainLine: match.mainLine,
      bttsO15: match.bttsO15,
      bttsO25: match.bttsO25,
      mainHandicap: match.mainHandicap || '0'
    });
    setShowResult(true);
    setActiveTab('home');
  };

  const isCurrentMatchSaved = useMemo(() => {
    const matchId = `${inputs.homeTeam}-${inputs.awayTeam}`;
    return savedMatches.some(m => m.id === matchId);
  }, [savedMatches, inputs.homeTeam, inputs.awayTeam]);

  const groupedMatches = useMemo(() => {
    const groups: { [year: string]: { [month: string]: { [day: string]: SavedMatch[] } } } = {};
    
    [...savedMatches].sort((a, b) => b.timestamp - a.timestamp).forEach(match => {
      const date = new Date(match.timestamp);
      const y = date.getFullYear().toString();
      const m = (date.getMonth() + 1).toString();
      const d = date.getDate().toString();
      
      if (!groups[y]) groups[y] = {};
      if (!groups[y][m]) groups[y][m] = {};
      if (!groups[y][m][d]) groups[y][m][d] = [];
      
      groups[y][m][d].push(match);
    });
    
    return groups;
  }, [savedMatches]);

  const handleResetData = () => {
    if (window.confirm(t.resetConfirm)) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        console.log("Uploaded file content:", content);
        
        localStorage.setItem('isDataImported', 'true');
        localStorage.setItem('analysisCode', content);
        
        setIsDataImported(true);
        setAnalysisCode(content);
        
        if (file.name.endsWith('.py')) {
          setToast(t.pythonSupport);
        } else {
          setToast(t.dataUpdated);
        }
      };
      reader.readAsText(file);
    }
  };

  const updateMatchResult = (id: string, result: 'win' | 'loss' | 'pending') => {
    setSavedMatches(prev => prev.map(m => m.id === id ? { ...m, result } : m));
  };

  const fileUpdateRef = useRef<HTMLInputElement>(null);

  const handleAnalyze = () => {
    if (!inputs.homeTeam || !inputs.awayTeam || !inputs.bttsO15 || !inputs.bttsO25) {
      setToast(t.inputMissing);
      return;
    }
    setIsAnalyzing(true);
  };

  const onAnalysisComplete = () => {
    setIsAnalyzing(false);
    setShowResult(true);
    confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 } });

    if (analysis) {
      const matchId = `${inputs.homeTeam}-${inputs.awayTeam}`;
      const newAnalysis: SavedMatch = {
        id: matchId,
        homeTeam: inputs.homeTeam,
        awayTeam: inputs.awayTeam,
        recommendation: analysis.step5.recommendation,
        bet: analysis.step5.bet,
        confidence: analysis.step5.confidence,
        timestamp: Date.now(),
        mainLine: inputs.mainLine,
        bttsO15: inputs.bttsO15,
        bttsO25: inputs.bttsO25,
        mainHandicap: inputs.mainHandicap
      };
      setRecentAnalyses(prev => [newAnalysis, ...prev.filter(m => m.id !== matchId)].slice(0, 5));
    }
  };

  return (
    <div className={`min-h-screen pb-32 transition-colors duration-500 ${currentTheme === 'dark' ? 'bg-black text-white' : 'bg-white text-gray-900'}`}>
      <style>
        {`
          :root {
            --accent-color: ${profile.theme === 'custom' ? profile.customColor : '#f97316'};
            --accent-color-rgb: ${profile.theme === 'custom' ? hexToRgb(profile.customColor) : '249, 115, 22'};
          }
          .text-orange-500 { color: var(--accent-color) !important; }
          .bg-orange-500 { background-color: var(--accent-color) !important; }
          .border-orange-500 { border-color: var(--accent-color) !important; }
          .bg-orange-50 { background-color: rgba(var(--accent-color-rgb), 0.1) !important; }
          .bg-orange-100 { background-color: rgba(var(--accent-color-rgb), 0.2) !important; }
          .text-orange-600 { color: color-mix(in srgb, var(--accent-color) 90%, black) !important; }
          .text-orange-700 { color: color-mix(in srgb, var(--accent-color) 80%, black) !important; }
          .text-orange-900 { color: color-mix(in srgb, var(--accent-color) 60%, black) !important; }
          .ring-orange-500 { --tw-ring-color: var(--accent-color) !important; }
          .shadow-orange-500\\/20 { --tw-shadow-color: rgba(var(--accent-color-rgb), 0.2) !important; }
          .fill-orange-500 { fill: var(--accent-color) !important; }
          
          /* Custom Scrollbar */
          ::-webkit-scrollbar { width: 6px; }
          ::-webkit-scrollbar-track { background: transparent; }
          ::-webkit-scrollbar-thumb { 
            background: var(--accent-color); 
            border-radius: 10px; 
            opacity: 0.5;
          }
        `}
      </style>
      <TopNav onOpenProfile={() => setIsProfileOpen(true)} userAvatar={profile.avatar} />
      
      <AnimatePresence>
        {isAnalyzing && <GoalLoading onComplete={onAnalysisComplete} language={profile.language} />}
        {toast && <Toast message={toast} onHide={() => setToast(null)} language={profile.language} />}
        {isProfileOpen && (
          <ProfileModal 
            isOpen={isProfileOpen} 
            onClose={() => setIsProfileOpen(false)} 
            profile={profile}
            onSave={(p) => {
              setProfile(p);
              setIsProfileOpen(false);
            }}
          />
        )}
      </AnimatePresence>

      <main className="px-6 space-y-10">
        {activeTab === 'home' ? (
          <>
            {!isDataImported ? (
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-8">
                <div className="w-32 h-32 bg-gray-50 dark:bg-white/5 rounded-full flex items-center justify-center relative">
                  <RefreshCcw className="w-16 h-16 text-gray-200 dark:text-gray-700 animate-spin-slow" />
                  <div className="absolute inset-0 border-4 border-dashed border-gray-100 dark:border-white/5 rounded-full animate-spin-slow" />
                </div>
                <div className="space-y-3 px-10">
                  <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight">{t.noSavedMatches}</h3>
                  <p className="text-sm text-gray-400 leading-relaxed max-w-xs mx-auto">{t.savedMatchesDesc}</p>
                </div>
                <button 
                  onClick={() => fileUpdateRef.current?.click()}
                  className="bg-orange-500 text-white px-10 py-4 rounded-3xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-orange-500/20 hover:scale-105 transition-all active:scale-95"
                >
                  {t.updateData}
                </button>
              </div>
            ) : (
              <>
                {/* Hero Card */}
            <section className="relative mt-4">
              <div className="relative overflow-hidden rounded-[40px]">
                <motion.div 
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.8}
                  onDragEnd={(_, info) => {
                    const threshold = 50;
                    if (info.offset.x < -threshold && heroSlideIndex < 3) {
                      setHeroSlideIndex(prev => prev + 1);
                    } else if (info.offset.x > threshold && heroSlideIndex > 0) {
                      setHeroSlideIndex(prev => prev - 1);
                    }
                  }}
                  animate={{ x: `-${heroSlideIndex * 100}%` }}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  className="flex"
                >
                  {/* Tab 0: Main Analysis / VIP Board */}
                  <div className="w-full shrink-0 px-0">
                    <motion.div 
                      className={`relative h-[500px] w-full bg-gradient-to-br ${heroGradients[heroColorIndex]} p-8 flex flex-col justify-end text-white shadow-2xl transition-all duration-1000`}
                    >
                      <div className="absolute inset-0 opacity-20 mix-blend-overlay">
                        <img 
                          src="https://picsum.photos/seed/stadium/800/1200" 
                          alt="Stadium" 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      
                      <div className="absolute top-8 left-8">
                        <VNTime />
                      </div>

                      <div className="absolute top-8 right-8 flex gap-3">
                        {showResult && (
                          <button 
                            onClick={toggleSaveMatch}
                            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${isCurrentMatchSaved ? 'bg-red-50 text-red-500' : 'bg-white text-black'}`}
                          >
                            <Heart className={`w-6 h-6 ${isCurrentMatchSaved ? 'fill-current' : ''}`} />
                          </button>
                        )}
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                          <ArrowUpRight className="w-6 h-6 text-black" />
                        </div>
                      </div>

                      <div className="relative z-10 space-y-4">
                        <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                          <TrendingUp className="w-3 h-3" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em]">{t.highWinProb}</span>
                        </div>

                        <div className="space-y-1">
                          <motion.h2 
                            key={showResult ? 'result' : 'default'}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="text-8xl font-black tracking-tighter leading-none"
                          >
                            {showResult ? (analysis?.step5.recommendation === 'OVER' ? 'OVER' : 'UNDER') : 'VIP'}
                          </motion.h2>
                          <p className="text-sm font-bold uppercase tracking-widest opacity-80">
                            {showResult ? t.analysisConfirmed : t.matchAnalysisBoard}
                          </p>
                        </div>

                        <h3 className="text-3xl font-bold leading-tight mt-4 min-h-[4rem]">
                          {showResult 
                            ? `${inputs.homeTeam} vs ${inputs.awayTeam}` 
                            : t.realTimePredictions}
                        </h3>
                        
                        {showResult && (
                          <div className="flex gap-2">
                            {[...Array(analysis?.step5.confidence || 0)].map((_, i) => (
                              <div key={i} className="w-8 h-1 bg-white rounded-full" />
                            ))}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  </div>

                  {/* Tabs 1-3: Suggestions or Saved Matches */}
                  {displaySuggestions.map((s, idx) => (
                    <div key={s.id} className="w-full shrink-0 px-0">
                      <div className={`relative h-[500px] w-full bg-gradient-to-br ${heroGradients[(heroColorIndex + idx + 1) % heroGradients.length]} p-8 flex flex-col justify-end text-white shadow-2xl transition-all duration-1000`}>
                        <div className="absolute inset-0 opacity-20 mix-blend-overlay">
                          <img 
                            src={`https://picsum.photos/seed/match${s.id}/800/1200`} 
                            alt="Stadium" 
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        
                        <div className="absolute top-8 left-8">
                          <VNTime />
                        </div>

                        <div className="absolute top-8 right-8 flex gap-3">
                          {('isRecent' in s || 'isSaved' in s) && (
                            <div className="w-12 h-12 bg-orange-500 text-white rounded-full flex items-center justify-center shadow-lg">
                              <TrendingUp className="w-6 h-6" />
                            </div>
                          )}
                          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                            <ArrowUpRight className="w-6 h-6 text-black" />
                          </div>
                        </div>

                        <div className="relative z-10 space-y-4">
                          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                            <TrendingUp className="w-3 h-3" />
                            <span className="text-[10px] font-black uppercase tracking-[0.2em]">
                              {('isRecent' in s || 'isSaved' in s) ? t.analysisResults : t.highWinProb}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h2 className="text-8xl font-black tracking-tighter leading-none">
                              {s.type === 'OVER' ? t.over : t.under}
                            </h2>
                            <p className="text-sm font-bold uppercase tracking-widest opacity-80">
                              {('isRecent' in s || 'isSaved' in s) ? t.analysisConfirmed : t.vipSuggestion}
                            </p>
                          </div>

                          <h3 className="text-3xl font-bold leading-tight mt-4 min-h-[4rem]">
                            {s.home} vs {s.away}
                          </h3>
                          
                          <div className="flex gap-2">
                            {[...Array(s.confidence)].map((_, i) => (
                              <div key={i} className="w-8 h-1 bg-white rounded-full" />
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </motion.div>
              </div>
              
              {/* Pagination Dots */}
              <div className="flex justify-center gap-2 mt-6">
                {[0, 1, 2, 3].map((idx) => (
                  <button
                    key={idx}
                    onClick={() => setHeroSlideIndex(idx)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${heroSlideIndex === idx ? 'bg-orange-500 w-6' : 'bg-gray-200 dark:bg-white/10'}`}
                  />
                ))}
              </div>
            </section>

            {/* Matchs Section (Inputs or Results) */}
            <section className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-black tracking-tight text-orange-500">
                  {showResult ? t.analysisResults : t.matchesTitle}
                </h2>
                {showResult && (
                  <button 
                    onClick={() => setShowResult(false)}
                    className="text-orange-500 font-bold text-sm"
                  >
                    {t.backToInputs}
                  </button>
                )}
              </div>

              <AnimatePresence mode="wait">
                {!showResult ? (
                  <motion.div 
                    key="inputs"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <InputField 
                        label={t.homeTeam} 
                        value={inputs.homeTeam} 
                        onChange={(v: string) => setInputs(prev => ({ ...prev, homeTeam: v }))}
                        placeholder={t.teamA}
                      />
                      <InputField 
                        label={t.awayTeam} 
                        value={inputs.awayTeam} 
                        onChange={(v: string) => setInputs(prev => ({ ...prev, awayTeam: v }))}
                        placeholder={t.teamB}
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{t.mainLine}</label>
                      <select 
                        value={inputs.mainLine}
                        onChange={(e) => setInputs(prev => ({ ...prev, mainLine: e.target.value }))}
                        className="w-full bg-gray-50 dark:bg-white/5 border-none rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-orange-500 transition-all font-medium appearance-none dark:text-white"
                      >
                        {Array.from({ length: 15 }, (_, i) => 1.5 + i * 0.25).map(val => (
                          <option key={val} value={val}>{val}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <InputField 
                        label="BTTS + O1.5" 
                        type="number"
                        value={inputs.bttsO15} 
                        onChange={(v: string) => setInputs(prev => ({ ...prev, bttsO15: v }))}
                        placeholder={t.odds}
                      />
                      <InputField 
                        label="BTTS + O2.5" 
                        type="number"
                        value={inputs.bttsO25} 
                        onChange={(v: string) => setInputs(prev => ({ ...prev, bttsO25: v }))}
                        placeholder={t.odds}
                      />
                    </div>

                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{t.mainHandicap}</label>
                      <select 
                        value={inputs.mainHandicap}
                        onChange={(e) => setInputs(prev => ({ ...prev, mainHandicap: e.target.value }))}
                        className="w-full bg-gray-50 dark:bg-white/5 border-none rounded-2xl px-4 py-3 text-sm focus:ring-2 focus:ring-orange-500 transition-all font-medium appearance-none dark:text-white"
                      >
                        {Array.from({ length: 33 }, (_, i) => i * 0.125 * 2).filter((_, i) => i % 1 === 0).map((_, i) => {
                          const val = i * 0.25;
                          return <option key={val} value={val}>{val}</option>;
                        })}
                      </select>
                    </div>

                    <button 
                      onClick={handleAnalyze}
                      className="w-full bg-black text-white py-5 rounded-[30px] font-black uppercase tracking-widest text-sm flex items-center justify-center gap-3 hover:scale-[0.98] active:scale-95 transition-all shadow-xl"
                    >
                      {t.analyzeMatch} <ChevronRight className="w-5 h-5" />
                    </button>
                  </motion.div>
                ) : (
                  <motion.div 
                    key="results"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-6"
                  >
                    <div className="bg-gray-50 dark:bg-white/5 rounded-[30px] p-8 space-y-6 border-2 border-orange-500 shadow-2xl shadow-orange-500/10">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <p className="text-[10px] font-black text-orange-500 uppercase tracking-[0.3em]">{t.recommendedBet}</p>
                          <h4 className="text-5xl font-black text-gray-900 dark:text-white tracking-tighter">{analysis?.step5.bet}</h4>
                        </div>
                        <div className="flex flex-col items-end gap-4">
                          <button 
                            onClick={toggleSaveMatch}
                            className={`p-4 rounded-full shadow-lg transition-all ${isCurrentMatchSaved ? 'bg-red-500 text-white' : 'bg-white dark:bg-white/10 text-gray-400'}`}
                          >
                            <Heart className={`w-6 h-6 ${isCurrentMatchSaved ? 'fill-current' : ''}`} />
                          </button>
                          <div className="flex gap-1 bg-white dark:bg-white/10 p-2 rounded-2xl">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`w-5 h-5 ${i < (analysis?.step5.confidence || 0) ? 'fill-orange-500 text-orange-500' : 'text-gray-200'}`} 
                              />
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-white dark:bg-white/5 rounded-2xl border border-gray-100 dark:border-white/5 italic text-sm text-gray-600 dark:text-gray-400">
                        "{analysis?.step5.reason}"
                      </div>

                      <div className="space-y-4">
                        {[analysis?.step1, analysis?.step2, analysis?.step3].map((step, i) => (
                          <div key={i} className="flex items-center justify-between p-4 bg-white dark:bg-white/5 rounded-2xl border border-gray-100 dark:border-white/5">
                            <div className="space-y-1">
                              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{step?.title}</p>
                              <p className="font-bold dark:text-white">{step?.value}</p>
                            </div>
                            <span className={`text-[10px] font-black px-3 py-1 rounded-full border ${step?.color}`}>
                              {step?.evaluation === 'OVER' ? t.over : step?.evaluation === 'UNDER' ? t.under : step?.evaluation}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-6 bg-orange-50 rounded-[30px] border border-orange-100 flex gap-4">
                      <AlertCircle className="w-6 h-6 text-orange-500 shrink-0" />
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-orange-900">{t.optimalEntry}</p>
                        <p className="text-xs text-orange-700 leading-relaxed">
                          {analysis?.step5.recommendation === 'OVER' 
                            ? `${t.enterOver} ${parseFloat(inputs.mainLine) - 0.25} ${t.protectHalf}` 
                            : `${t.enterUnder} ${parseFloat(inputs.mainLine) + 0.25} ${t.protectHalf}`}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </section>
          </>
        )}
      </>
    ) : activeTab === 'saved' ? (
          <section className="space-y-8 mt-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h2 className="text-4xl font-black tracking-tighter text-orange-500">{t.savedMatches}</h2>
                <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest">{t.betHistory}</p>
              </div>
              <div className="bg-orange-100 text-orange-600 px-4 py-1 rounded-full text-xs font-black">
                {savedMatches.length} {t.items}
              </div>
            </div>

            {savedMatches.length === 0 ? (
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-20 h-20 bg-gray-50 dark:bg-white/5 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-10 h-10 text-gray-200 dark:text-gray-700" />
                </div>
                <div className="space-y-1 px-10">
                  <p className="font-bold text-gray-900 dark:text-white">{t.noSavedMatches}</p>
                  <p className="text-sm text-gray-400 leading-relaxed">{t.savedMatchesDesc}</p>
                </div>
              </div>
            ) : (
              <div className="space-y-10">
                {Object.entries(groupedMatches).sort(([a], [b]) => parseInt(b) - parseInt(a)).map(([year, months]) => (
                  <div key={year} className="space-y-8">
                    <div className="flex items-center gap-4">
                      <div className="h-px flex-1 bg-gray-100" />
                      <span className="text-[10px] font-black text-gray-300 uppercase tracking-[0.4em]">{t.year} {year}</span>
                      <div className="h-px flex-1 bg-gray-100" />
                    </div>

                    {Object.entries(months as any).sort(([a], [b]) => parseInt(b) - parseInt(a)).map(([month, days]: [string, any]) => (
                      <div key={month} className="space-y-6">
                        <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                          <div className="w-1 h-4 bg-orange-500 rounded-full" />
                          {t.month} {month}
                        </h3>

                        {Object.entries(days as any).sort(([a], [b]) => parseInt(b) - parseInt(a)).map(([day, matches]: [string, any]) => (
                          <div key={day} className="space-y-4">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold text-gray-400">{t.day} {day}</span>
                              <div className="h-px flex-1 bg-gray-50" />
                            </div>
                            
                            <div className="grid gap-4">
                              {(matches as SavedMatch[]).map((match) => (
                                  <motion.div 
                                    layout
                                    key={match.id}
                                    className="bg-gray-50 dark:bg-white/5 rounded-[30px] p-6 flex flex-col gap-4 group cursor-pointer hover:bg-gray-100 dark:hover:bg-white/10 transition-colors"
                                    onClick={() => loadSavedMatch(match)}
                                  >
                                    <div className="flex items-center justify-between">
                                      <div className="space-y-2">
                                        <h4 className="text-xl font-black dark:text-white">{match.homeTeam} vs {match.awayTeam}</h4>
                                        <div className="flex items-center gap-3">
                                          <span className={`text-[10px] font-black px-3 py-1 rounded-full border ${match.recommendation === 'OVER' ? COLORS.red : COLORS.black}`}>
                                            {match.recommendation === 'OVER' ? t.over : t.under}
                                          </span>
                                          <span className="text-xs font-bold text-gray-500">{match.bet}</span>
                                        </div>
                                      </div>
                                      <div className="flex flex-col items-end gap-4">
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setSavedMatches(prev => prev.filter(m => m.id !== match.id));
                                          }}
                                          className="p-2 text-gray-300 hover:text-red-500 transition-colors"
                                        >
                                          <X className="w-5 h-5" />
                                        </button>
                                        <div className="flex gap-0.5">
                                          {[...Array(5)].map((_, i) => (
                                            <Star 
                                              key={i} 
                                              className={`w-3 h-3 ${i < match.confidence ? 'fill-orange-500 text-orange-500' : 'text-gray-200'}`} 
                                            />
                                          ))}
                                        </div>
                                      </div>
                                    </div>

                                    {/* Result Management */}
                                    <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-white/5">
                                      <div className="flex items-center gap-2">
                                        <div className={`w-2 h-2 rounded-full ${
                                          match.result === 'win' ? 'bg-green-500' : 
                                          match.result === 'loss' ? 'bg-red-500' : 'bg-gray-300'
                                        }`} />
                                        <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                                          {match.result === 'win' ? t.win : match.result === 'loss' ? t.loss : t.pending}
                                        </span>
                                      </div>
                                      <div className="flex gap-2">
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            updateMatchResult(match.id, 'win');
                                          }}
                                          className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                                            match.result === 'win' ? 'bg-green-500 text-white' : 'bg-gray-100 dark:bg-white/10 text-gray-400'
                                          }`}
                                        >
                                          {t.win}
                                        </button>
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            updateMatchResult(match.id, 'loss');
                                          }}
                                          className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                                            match.result === 'loss' ? 'bg-red-500 text-white' : 'bg-gray-100 dark:bg-white/10 text-gray-400'
                                          }`}
                                        >
                                          {t.loss}
                                        </button>
                                      </div>
                                    </div>
                                  </motion.div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </section>
        ) : (
          <section className="space-y-8 mt-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <h2 className="text-4xl font-black tracking-tighter text-orange-500">{t.more}</h2>
                <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest">{t.designBy}</p>
              </div>
            </div>

            <div className="space-y-6">
              {/* Theme Section */}
              <div className="bg-gray-50 dark:bg-gray-900 rounded-[30px] p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center">
                    <Star className="w-5 h-5 text-orange-500" />
                  </div>
                  <h3 className="font-black uppercase tracking-widest text-sm text-orange-500">{t.theme}</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { id: 'light', label: t.themeLight },
                    { id: 'dark', label: t.themeDark },
                    { id: 'realtime', label: t.themeRealTime },
                    { id: 'custom', label: t.themeCustom }
                  ].map((mode) => (
                    <button
                      key={mode.id}
                      onClick={() => setProfile(prev => ({ ...prev, theme: mode.id as any }))}
                      className={`py-4 rounded-2xl text-xs font-bold border transition-all ${
                        profile.theme === mode.id 
                          ? 'bg-orange-500 text-white border-orange-500 shadow-lg shadow-orange-500/20' 
                          : 'bg-white dark:bg-gray-800 text-gray-400 border-gray-100 dark:border-gray-700'
                      }`}
                      style={profile.theme === mode.id ? { backgroundColor: 'var(--accent-color)', borderColor: 'var(--accent-color)' } : {}}
                    >
                      {mode.label}
                    </button>
                  ))}
                </div>

                {profile.theme === 'custom' && (
                  <div className="pt-4 space-y-4">
                    <div className="flex flex-wrap gap-2">
                      {['#f97316', '#ef4444', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4', '#f59e0b'].map(color => (
                        <button
                          key={color}
                          onClick={() => setProfile(prev => ({ ...prev, customColor: color }))}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${profile.customColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-60 hover:opacity-100'}`}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="relative w-12 h-12 rounded-xl overflow-hidden border-2 border-white/20 shadow-inner bg-white/5 flex items-center justify-center">
                        <input 
                          type="color" 
                          value={profile.customColor}
                          onChange={(e) => setProfile(prev => ({ ...prev, customColor: e.target.value }))}
                          className="w-full h-full cursor-pointer scale-150"
                        />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-bold text-orange-500 uppercase tracking-widest">{t.pickAccentColor}</p>
                        <button 
                          onClick={() => setProfile(prev => ({ ...prev, customColor: '#f97316' }))}
                          className="text-[10px] font-bold text-gray-400 uppercase hover:text-white transition-colors"
                        >
                          Reset Default
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Language Section */}
              <div className="bg-gray-50 dark:bg-gray-900 rounded-[30px] p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center">
                    <Globe className="w-5 h-5 text-orange-500" />
                  </div>
                  <h3 className="font-black uppercase tracking-widest text-sm text-orange-500">{t.language}</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { id: 'en', label: 'English' },
                    { id: 'vi', label: 'Tiếng Việt' }
                  ].map((lang) => (
                    <button
                      key={lang.id}
                      onClick={() => setProfile(prev => ({ ...prev, language: lang.id as any }))}
                      className={`py-4 rounded-2xl text-xs font-bold border transition-all ${
                        profile.language === lang.id 
                          ? 'bg-orange-500 text-white border-orange-500 shadow-lg shadow-orange-500/20' 
                          : 'bg-white dark:bg-gray-800 text-gray-400 border-gray-100 dark:border-gray-700'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

export default function AppWrapper() {
  return (
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
}
